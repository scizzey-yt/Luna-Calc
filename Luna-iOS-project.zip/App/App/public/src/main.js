const $ = (selector) => document.querySelector(selector);
const expressionEl = $('#expression');
const resultEl = $('#result');
const resultRow = $('#resultRow');
const historyPanel = $('#historyPanel');
const settingsPanel = $('#settingsPanel');
const scrim = $('#scrim');

let expression = '';
let resultValue = '';
let justSolved = false;
let toastTimer;
let history = loadHistory();
let settings = loadSettings();

function loadHistory() {
  try {
    return JSON.parse(localStorage.getItem('luna-history') || localStorage.getItem('luma-history') || '[]');
  } catch {
    return [];
  }
}

function saveHistory() {
  try { localStorage.setItem('luna-history', JSON.stringify(history.slice(0, 30))); } catch {}
}

function loadSettings() {
  const defaults = { theme: 'midnight', textSize: 1, keySize: 1, animations: true, sound: false };
  try {
    const saved = JSON.parse(localStorage.getItem('luna-settings') || '{}');
    return {
      ...defaults,
      ...saved,
      theme: ['midnight', 'paper', 'ocean', 'lavender'].includes(saved.theme) ? saved.theme : defaults.theme,
      textSize: [0, 1, 2].includes(Number(saved.textSize)) ? Number(saved.textSize) : defaults.textSize,
      keySize: [0, 1, 2].includes(Number(saved.keySize)) ? Number(saved.keySize) : defaults.keySize,
      animations: typeof saved.animations === 'boolean' ? saved.animations : defaults.animations,
      sound: typeof saved.sound === 'boolean' ? saved.sound : defaults.sound,
    };
  } catch {
    return defaults;
  }
}

function saveSettings() {
  try { localStorage.setItem('luna-settings', JSON.stringify(settings)); } catch {}
}

function applySettings() {
  const root = document.documentElement;
  root.dataset.theme = settings.theme;
  root.dataset.motion = settings.animations ? 'on' : 'off';
  root.style.setProperty('--type-scale', ['.9', '1', '1.14'][settings.textSize]);
  root.style.setProperty('--key-scale', ['.9', '1', '1.08'][settings.keySize]);
  document.querySelectorAll('[data-theme-choice]').forEach((button) => {
    button.setAttribute('aria-pressed', String(button.dataset.themeChoice === settings.theme));
  });
  $('#textSize').value = String(settings.textSize);
  $('#keySize').value = String(settings.keySize);
  $('#textSizeLabel').textContent = ['Compact', 'Standard', 'Large'][settings.textSize];
  $('#keySizeLabel').textContent = ['Compact', 'Balanced', 'Large'][settings.keySize];
  $('#animationSetting').checked = settings.animations;
  $('#soundSetting').checked = settings.sound;
}

function cleanNumber(number) {
  if (!Number.isFinite(number)) throw Error('Math error');
  if (Math.abs(number) > 1e14) throw Error('Number is too large');
  return Number.parseFloat(number.toPrecision(12)).toString();
}

function tokenize(input) {
  const source = input.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('−', '-').replaceAll(' ', '');
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const char = source[index];
    if (/[0-9.]/.test(char)) {
      let number = '';
      let dots = 0;
      while (index < source.length && /[0-9.]/.test(source[index])) {
        if (source[index] === '.' && ++dots > 1) throw Error('Check that decimal');
        number += source[index++];
      }
      if (number === '.') throw Error('Incomplete number');
      tokens.push({ type: 'num', value: Number(number) });
      continue;
    }
    if ('+-*/%()'.includes(char)) {
      tokens.push({ type: 'op', value: char });
      index++;
      continue;
    }
    throw Error('That expression looks off');
  }
  return tokens;
}

function calculate(input) {
  let tokens = tokenize(input);
  if (!tokens.length) throw Error('Enter a calculation');
  const expanded = [];
  for (const token of tokens) {
    const previous = expanded.at(-1);
    if (token.type === 'num' && previous?.value === ')') expanded.push({ type: 'op', value: '*' });
    if (token.value === '(' && previous?.type === 'num') expanded.push({ type: 'op', value: '*' });
    expanded.push(token);
  }
  tokens = expanded;

  let position = 0;
  function primary() {
    const token = tokens[position++];
    if (!token) throw Error('Finish your calculation');
    if (token.type === 'num') return token.value;
    if (token.value === '+' || token.value === '-') {
      const value = primary();
      return token.value === '-' ? -value : value;
    }
    if (token.value === '(') {
      const value = add();
      if (tokens[position]?.value !== ')') throw Error('Close your bracket');
      position++;
      return value;
    }
    throw Error('Check the expression');
  }
  function factor() {
    let value = primary();
    let isPercent = false;
    while (tokens[position]?.value === '%') {
      position++;
      value /= 100;
      isPercent = true;
    }
    return { value, percentOf: isPercent ? value * 100 : null };
  }
  function multiply() {
    let left = factor();
    while (tokens[position] && ['*', '/'].includes(tokens[position].value)) {
      const operator = tokens[position++].value;
      const right = factor();
      left = { value: operator === '*' ? left.value * right.value : left.value / right.value, percentOf: null };
    }
    return left;
  }
  function add() {
    let left = multiply();
    while (tokens[position] && ['+', '-'].includes(tokens[position].value)) {
      const operator = tokens[position++].value;
      const right = multiply();
      const amount = right.percentOf === null ? right.value : left.value * right.percentOf / 100;
      left = { value: operator === '+' ? left.value + amount : left.value - amount, percentOf: null };
    }
    return left;
  }

  const value = add().value;
  if (position < tokens.length) throw Error('Check the expression');
  return cleanNumber(value);
}

function prettyResult(value) {
  const [number, exponent] = value.split('e');
  const grouped = Number(number).toLocaleString('en-US', { maximumFractionDigits: 12, useGrouping: true });
  return exponent ? `${grouped}e${exponent}` : grouped;
}

function render() {
  expressionEl.textContent = expression;
  resultEl.classList.remove('is-error');
  resultRow.classList.toggle('has-value', Boolean(resultValue));
  resultEl.textContent = resultValue ? prettyResult(resultValue) : '';
}

function pulse(button) {
  button.classList.add('pressed');
  setTimeout(() => button.classList.remove('pressed'), settings.animations ? 130 : 30);
  if (!settings.sound) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    const context = new AudioContextClass();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.frequency.value = button.dataset.action === 'equals' ? 580 : 360;
    gain.gain.value = 0.025;
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start();
    oscillator.stop(context.currentTime + 0.035);
    oscillator.onended = () => context.close();
  } catch {}
}

function append(value) {
  if (justSolved) {
    expression = /[0-9.(]/.test(value) ? '' : resultValue;
    resultValue = '';
    justSolved = false;
  }
  if (/[+−×÷]/.test(value) && /[+−×÷]$/.test(expression)) expression = expression.slice(0, -1);
  const currentNumber = expression.split(/[+−×÷()%]/).at(-1);
  if (value === '.' && currentNumber.includes('.')) return;
  expression += value;
  render();
}

function handleAction(action) {
  if (action === 'clear') {
    expression = '';
    resultValue = '';
    justSolved = false;
    render();
    return;
  }
  if (action === 'backspace') {
    expression = expression.slice(0, -1);
    resultValue = '';
    justSolved = false;
    render();
    return;
  }
  if (action === 'paren') {
    if (justSolved) expression = '', resultValue = '', justSolved = false;
    const opens = (expression.match(/\(/g) || []).length;
    const closes = (expression.match(/\)/g) || []).length;
    expression += opens > closes && !/[+−×÷(]$/.test(expression) ? ')' : '(';
    render();
    return;
  }
  if (action === 'equals') {
    if (!expression) return;
    try {
      resultValue = calculate(expression);
      history.unshift({ expression, result: resultValue });
      history = history.slice(0, 30);
      saveHistory();
      renderHistory();
      justSolved = true;
      render();
    } catch (error) {
      showToast(error.message || 'Check your calculation');
    }
  }
}

function showDrawer(name) {
  const openSettings = name === 'settings';
  const openHistory = name === 'history';
  settingsPanel.classList.toggle('open', openSettings);
  historyPanel.classList.toggle('open', openHistory);
  settingsPanel.setAttribute('aria-hidden', String(!openSettings));
  historyPanel.setAttribute('aria-hidden', String(!openHistory));
  scrim.classList.toggle('open', openSettings || openHistory);
  if (openHistory) renderHistory();
}

function renderHistory() {
  const list = $('#historyList');
  if (!history.length) {
    list.innerHTML = '<div class="history-empty">Your calculations will appear here.</div>';
    return;
  }
  list.innerHTML = history.map((item, index) => `<article class="history-item" data-history="${index}"><div class="hist-expr">${escapeHtml(item.expression)}</div><div class="hist-result">${escapeHtml(prettyResult(item.result))}</div></article>`).join('');
  list.querySelectorAll('[data-history]').forEach((element) => element.addEventListener('click', () => {
    const item = history[Number(element.dataset.history)];
    expression = item.expression;
    resultValue = item.result;
    justSolved = true;
    render();
    showDrawer('');
  }));
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2100);
}

document.querySelectorAll('.key').forEach((button) => button.addEventListener('click', () => {
  pulse(button);
  if (button.dataset.value) append(button.dataset.value);
  else handleAction(button.dataset.action);
}));

$('#historyToggle').addEventListener('click', () => showDrawer('history'));
$('#historyClose').addEventListener('click', () => showDrawer(''));
$('#settingsToggle').addEventListener('click', () => showDrawer('settings'));
$('#settingsClose').addEventListener('click', () => showDrawer(''));
scrim.addEventListener('click', () => showDrawer(''));
$('#clearHistory').addEventListener('click', () => {
  history = [];
  saveHistory();
  renderHistory();
  showToast('History cleared');
});
$('#signToggle').addEventListener('click', () => {
  if (justSolved) expression = resultValue;
  resultValue = '';
  justSolved = false;
  if (!expression) expression = '−';
  else if (expression.startsWith('−(') && expression.endsWith(')')) expression = expression.slice(2, -1);
  else expression = `−(${expression})`;
  render();
});
$('#brandMark').addEventListener('click', () => handleAction('clear'));

document.querySelectorAll('[data-theme-choice]').forEach((button) => button.addEventListener('click', () => {
  settings.theme = button.dataset.themeChoice;
  saveSettings();
  applySettings();
}));
$('#textSize').addEventListener('input', (event) => {
  settings.textSize = Number(event.target.value);
  saveSettings();
  applySettings();
});
$('#keySize').addEventListener('input', (event) => {
  settings.keySize = Number(event.target.value);
  saveSettings();
  applySettings();
});
$('#animationSetting').addEventListener('change', (event) => {
  settings.animations = event.target.checked;
  saveSettings();
  applySettings();
});
$('#soundSetting').addEventListener('change', (event) => {
  settings.sound = event.target.checked;
  saveSettings();
  applySettings();
  showToast(settings.sound ? 'Key sounds on' : 'Key sounds off');
});

window.addEventListener('keydown', (event) => {
  if (event.ctrlKey || event.metaKey) return;
  if (settingsPanel.classList.contains('open') || historyPanel.classList.contains('open')) {
    if (event.key === 'Escape') showDrawer('');
    return;
  }
  if (/[0-9.()+%]/.test(event.key) && event.key.length === 1) append(event.key);
  else if (event.key === '*') append('×');
  else if (event.key === '/') append('÷');
  else if (event.key === '+') append('+');
  else if (event.key === '-') append('−');
  else if (event.key === 'Enter' || event.key === '=') { event.preventDefault(); handleAction('equals'); }
  else if (event.key === 'Backspace') handleAction('backspace');
  else if (event.key === 'Escape') handleAction('clear');
});

applySettings();
render();
renderHistory();
