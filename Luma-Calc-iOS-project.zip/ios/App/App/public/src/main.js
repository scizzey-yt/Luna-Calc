const $ = (s) => document.querySelector(s);
const expressionEl = $('#expression');
const resultEl = $('#result');
const footerHint = $('#footerHint');
const historyPanel = $('#historyPanel');
const scrim = $('#scrim');
let expression = '';
let justSolved = false;
let soundOn = false;
let history = loadHistory();
let toastTimer;

function loadHistory(){try{return JSON.parse(localStorage.getItem('luma-history')||'[]')}catch{return []}}
function saveHistory(){try{localStorage.setItem('luma-history',JSON.stringify(history.slice(0,30)))}catch{}}
function cleanNumber(n){if(!Number.isFinite(n))throw Error('Math error');if(Math.abs(n)>1e14)throw Error('Number is too large');return Number.parseFloat(n.toPrecision(12)).toString()}
function tokenize(input){const s=input.replaceAll('×','*').replaceAll('÷','/').replaceAll('−','-').replaceAll(' ','');const tokens=[];let i=0;while(i<s.length){const c=s[i];if(/[0-9.]/.test(c)){let n='';let dots=0;while(i<s.length&&/[0-9.]/.test(s[i])){if(s[i]==='.'&&++dots>1)throw Error('Check that decimal');n+=s[i++]}if(n==='.')throw Error('Incomplete number');tokens.push({type:'num',value:Number(n)});continue}if('+-*/%()'.includes(c)){tokens.push({type:'op',value:c});i++;continue}throw Error('That expression looks off')}return tokens}
function calculate(input){let t=tokenize(input);if(!t.length)throw Error('Enter a calculation');const expanded=[];for(let i=0;i<t.length;i++){const prev=expanded.at(-1),cur=t[i];if(cur.type==='num'&&prev?.type==='op'&&prev.value===')')expanded.push({type:'op',value:'*'});if(cur.type==='op'&&cur.value==='('&&prev?.type==='num')expanded.push({type:'op',value:'*'});expanded.push(cur)}t=expanded;
  let p=0;function primary(){const x=t[p++];if(!x)throw Error('Finish your calculation');if(x.type==='num')return x.value;if(x.value==='+'||x.value==='-'){const v=primary();return x.value==='-'?-v:v}if(x.value==='('){const v=add();if(t[p]?.value!==')')throw Error('Close your bracket');p++;return v}throw Error('Check the expression')}
  function factor(){let v=primary(),isPercent=false;while(t[p]?.value==='%'){p++;v/=100;isPercent=true}return{value:v,percentOf:isPercent?v*100:null}}
  function mul(){let a=factor();while(t[p]&&['*','/'].includes(t[p].value)){const op=t[p++].value,b=factor();a={value:op==='*'?a.value*b.value:a.value/b.value,percentOf:null}}return a}
  function add(){let a=mul();while(t[p]&&['+','-'].includes(t[p].value)){const op=t[p++].value,b=mul(),amount=b.percentOf===null?b.value:a.value*b.percentOf/100;a={value:op==='+'?a.value+amount:a.value-amount,percentOf:null}}return a}
  const value=add().value;if(p<t.length)throw Error('Check the expression');return cleanNumber(value)}
function prettyResult(s){if(s==='Error')return s;const [a,b]=s.split('e');const grouped=Number(a).toLocaleString('en-US',{maximumFractionDigits:12,useGrouping:true});return b?`${grouped}e${b}`:grouped}
function render(){expressionEl.innerHTML=expression?escapeHtml(expression):'<span class="placeholder">Your next calculation</span>';resultEl.classList.remove('is-error');if(!expression){resultEl.textContent='0';footerHint.textContent='Tap a key to begin';return}try{resultEl.textContent=prettyResult(calculate(expression));footerHint.textContent='Live result';}catch(e){if(/too large|Math error/.test(e.message)){resultEl.textContent='Error';resultEl.classList.add('is-error');footerHint.textContent='Check your calculation'}else{resultEl.textContent='…';footerHint.textContent='Keep going'}}}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function pulse(button){button.classList.add('pressed');setTimeout(()=>button.classList.remove('pressed'),130);if(soundOn){try{const C=window.AudioContext||window.webkitAudioContext;const c=new C(),o=c.createOscillator(),g=c.createGain();o.frequency.value=button.dataset.action==='equals'?580:360;g.gain.value=.025;o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.035);o.onended=()=>c.close()}catch{}}}
function append(value){if(justSolved){if(/[0-9.(]/.test(value))expression='';justSolved=false}if(/[+−×÷]/.test(value)&&/[+−×÷]$/.test(expression))expression=expression.slice(0,-1);if(value==='.'&&/[0-9]*\.?[0-9]*$/.test(expression.split(/[+−×÷()%]/).at(-1))&&expression.split(/[+−×÷()%]/).at(-1).includes('.'))return;expression+=value;render()}
function handleAction(action){if(action==='clear'){expression='';justSolved=false;render();return}if(action==='backspace'){expression=expression.slice(0,-1);justSolved=false;render();return}if(action==='paren'){if(justSolved){expression='';justSolved=false}const opens=(expression.match(/\(/g)||[]).length,closes=(expression.match(/\)/g)||[]).length;expression+=opens>closes&&!/[+−×÷(]$/.test(expression)?')':'(';render();return}if(action==='equals'){if(!expression)return;try{const value=calculate(expression);const row={expression,result:value};history.unshift(row);history=history.slice(0,30);saveHistory();renderHistory();expression=value;justSolved=true;render();footerHint.textContent='Saved to history';}catch(e){showToast(e.message||'Check your calculation')}return}}
function showHistory(open){historyPanel.classList.toggle('open',open);scrim.classList.toggle('open',open);historyPanel.setAttribute('aria-hidden',String(!open));if(open)renderHistory()}
function renderHistory(){const list=$('#historyList');if(!history.length){list.innerHTML='<div class="history-empty">A little room for your next<br>great idea.</div>';return}list.innerHTML=history.map((h,i)=>`<article class="history-item" data-history="${i}"><div class="hist-expr">${escapeHtml(h.expression)}</div><div class="hist-result">${escapeHtml(prettyResult(h.result))}</div></article>`).join('');list.querySelectorAll('[data-history]').forEach(el=>el.addEventListener('click',()=>{expression=history[Number(el.dataset.history)].result;justSolved=true;render();showHistory(false)}))}
function showToast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2100)}
document.querySelectorAll('.key').forEach(btn=>btn.addEventListener('click',()=>{pulse(btn);if(btn.dataset.value)append(btn.dataset.value);else handleAction(btn.dataset.action)}));
$('#historyToggle').addEventListener('click',()=>showHistory(true));$('#historyClose').addEventListener('click',()=>showHistory(false));scrim.addEventListener('click',()=>showHistory(false));
$('#clearHistory').addEventListener('click',()=>{history=[];saveHistory();renderHistory();showToast('History cleared')});
$('#signToggle').addEventListener('click',()=>{if(!expression){expression='−';render();return}if(expression.startsWith('−(')&&expression.endsWith(')'))expression=expression.slice(2,-1);else expression=`−(${expression})`;justSolved=false;render()});
$('#soundToggle').addEventListener('click',()=>{soundOn=!soundOn;$('#soundToggle').style.color=soundOn?'var(--mint)':'';showToast(soundOn?'Key sounds on':'Key sounds off')});
$('#brandMark').addEventListener('click',()=>{expression='';justSolved=false;render()});
window.addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey||historyPanel.classList.contains('open'))return;if(/[0-9.()+%]/.test(e.key)&&e.key.length===1)append(e.key);else if(e.key==='*')append('×');else if(e.key==='/')append('÷');else if(e.key==='+')append('+');else if(e.key==='-')append('−');else if(e.key==='Enter'||e.key==='='){e.preventDefault();handleAction('equals')}else if(e.key==='Backspace')handleAction('backspace');else if(e.key==='Escape')handleAction('clear')});
render();renderHistory();
