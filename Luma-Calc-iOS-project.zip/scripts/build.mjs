import { cp, mkdir, rm } from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const output = new URL('../dist/', import.meta.url);
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const entry of ['index.html', 'src']) {
  const source = new URL(`../${entry}`, import.meta.url);
  const target = new URL(`../dist/${entry}`, import.meta.url);
  await cp(source, target, { recursive: true });
}
for (const asset of ['icon.svg', 'manifest.webmanifest', 'apple-touch-icon.png']) {
  await cp(new URL(`../public/${asset}`, import.meta.url), new URL(`../dist/${asset}`, import.meta.url));
}
console.log('Luma Calc built into dist/.');
