Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $PSScriptRoot
$res = Join-Path $root 'android\app\src\main\res'
$densities = @(
    @{ Name = 'mipmap-mdpi'; Size = 48 },
    @{ Name = 'mipmap-hdpi'; Size = 72 },
    @{ Name = 'mipmap-xhdpi'; Size = 96 },
    @{ Name = 'mipmap-xxhdpi'; Size = 144 },
    @{ Name = 'mipmap-xxxhdpi'; Size = 192 },
    @{ Name = 'public'; Size = 180 },
    @{ Name = 'ios-appicon'; Size = 1024 }
)
$mint = [System.Drawing.ColorTranslator]::FromHtml('#78F0C3')
$white = [System.Drawing.ColorTranslator]::FromHtml('#F4FFF9')
$darkTop = [System.Drawing.ColorTranslator]::FromHtml('#242A36')
$darkBottom = [System.Drawing.ColorTranslator]::FromHtml('#12151D')

foreach ($density in $densities) {
    $size = $density.Size
    $scale = $size / 128.0
    $isIos = $density.Name -in @('public', 'ios-appicon')
    $folder = if ($density.Name -eq 'public') { Join-Path $root 'public' } elseif ($density.Name -eq 'ios-appicon') { Join-Path $root 'ios\App\App\Assets.xcassets\AppIcon.appiconset' } else { Join-Path $res $density.Name }
    $variants = if ($density.Name -eq 'public') { @('apple-touch-icon.png') } elseif ($density.Name -eq 'ios-appicon') { @('AppIcon-512@2x.png') } else { @('ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png') }
    foreach ($variant in $variants) {
        $bitmap = [System.Drawing.Bitmap]::new($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

        $background = $null
        if ($variant -ne 'ic_launcher_foreground.png') {
            $brush = [System.Drawing.Drawing2D.LinearGradientBrush]::new(
                [System.Drawing.RectangleF]::new(0, 0, $size, $size), $darkTop, $darkBottom, 45
            )
            if ($isIos) {
                $graphics.FillRectangle($brush, 0, 0, $size, $size)
                $brush.Dispose()
                $brush = $null
            } elseif ($variant -eq 'ic_launcher_round.png') {
                $background = [System.Drawing.Drawing2D.GraphicsPath]::new()
                $background.AddEllipse(1, 1, $size - 2, $size - 2)
            } else {
                $background = [System.Drawing.Drawing2D.GraphicsPath]::new()
                $radius = 35 * $scale
                $diameter = $radius * 2
                $background.AddArc(4 * $scale, 4 * $scale, $diameter, $diameter, 180, 90)
                $background.AddArc(($size - 4 * $scale - $diameter), 4 * $scale, $diameter, $diameter, 270, 90)
                $background.AddArc(($size - 4 * $scale - $diameter), ($size - 4 * $scale - $diameter), $diameter, $diameter, 0, 90)
                $background.AddArc(4 * $scale, ($size - 4 * $scale - $diameter), $diameter, $diameter, 90, 90)
                $background.CloseFigure()
            }
            if ($background) { $graphics.FillPath($brush, $background) }
            if ($brush) { $brush.Dispose() }
            if ($background) { $background.Dispose() }
        }

        $accent = [System.Drawing.Pen]::new($mint, 7 * $scale)
        $accent.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
        $accent.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
        $accent.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round
        $logo = [System.Drawing.Drawing2D.GraphicsPath]::new()
        $logo.AddLine(31 * $scale, 45 * $scale, 31 * $scale, 36 * $scale)
        $logo.AddArc(31 * $scale, 28 * $scale, 16 * $scale, 16 * $scale, 180, 90)
        $logo.AddLine(39 * $scale, 28 * $scale, 89 * $scale, 28 * $scale)
        $logo.AddArc(81 * $scale, 28 * $scale, 16 * $scale, 16 * $scale, 270, 90)
        $logo.AddLine(97 * $scale, 36 * $scale, 97 * $scale, 45 * $scale)
        $logo.StartFigure()
        $logo.AddLine(31 * $scale, 83 * $scale, 31 * $scale, 92 * $scale)
        $logo.AddArc(31 * $scale, 84 * $scale, 16 * $scale, 16 * $scale, 180, -90)
        $logo.AddLine(39 * $scale, 100 * $scale, 89 * $scale, 100 * $scale)
        $logo.AddArc(81 * $scale, 84 * $scale, 16 * $scale, 16 * $scale, 90, -90)
        $logo.AddLine(97 * $scale, 92 * $scale, 97 * $scale, 83 * $scale)
        $graphics.DrawPath($accent, $logo)
        $accent.Dispose()
        $logo.Dispose()

        $middle = [System.Drawing.Pen]::new($white, 8 * $scale)
        $middle.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
        $middle.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
        $graphics.DrawLine($middle, 39 * $scale, 64 * $scale, 89 * $scale, 64 * $scale)
        $middle.Dispose()
        foreach ($point in @('47,50', '81,50', '47,78', '81,78')) {
            $coordinates = $point.Split(',')
            $diameter = 8 * $scale
            $dot = [System.Drawing.SolidBrush]::new($mint)
            $graphics.FillEllipse($dot, ([double]$coordinates[0] * $scale - $diameter / 2), ([double]$coordinates[1] * $scale - $diameter / 2), $diameter, $diameter)
            $dot.Dispose()
        }

        $bitmap.Save((Join-Path $folder $variant), [System.Drawing.Imaging.ImageFormat]::Png)
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

$splashFolder = Join-Path $root 'ios\App\App\Assets.xcassets\Splash.imageset'
$splashSize = 2732
$splash = [System.Drawing.Bitmap]::new($splashSize, $splashSize, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$graphics = [System.Drawing.Graphics]::FromImage($splash)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.Clear([System.Drawing.ColorTranslator]::FromHtml('#090B10'))
$scale = $splashSize / 440.0
$offset = ($splashSize - 128 * $scale) / 2
$graphics.TranslateTransform($offset, $offset)
$graphics.ScaleTransform($scale, $scale)
$accent = [System.Drawing.Pen]::new($mint, 7)
$accent.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
$accent.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
$accent.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round
$logo = [System.Drawing.Drawing2D.GraphicsPath]::new()
$logo.AddLine(31, 45, 31, 36)
$logo.AddArc(31, 28, 16, 16, 180, 90)
$logo.AddLine(39, 28, 89, 28)
$logo.AddArc(81, 28, 16, 16, 270, 90)
$logo.AddLine(97, 36, 97, 45)
$logo.StartFigure()
$logo.AddLine(31, 83, 31, 92)
$logo.AddArc(31, 84, 16, 16, 180, -90)
$logo.AddLine(39, 100, 89, 100)
$logo.AddArc(81, 84, 16, 16, 90, -90)
$logo.AddLine(97, 92, 97, 83)
$graphics.DrawPath($accent, $logo)
$middle = [System.Drawing.Pen]::new($white, 8)
$middle.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
$middle.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
$graphics.DrawLine($middle, 39, 64, 89, 64)
foreach ($point in @('47,50', '81,50', '47,78', '81,78')) {
    $coordinates = $point.Split(',')
    $dot = [System.Drawing.SolidBrush]::new($mint)
    $graphics.FillEllipse($dot, ([double]$coordinates[0] - 4), ([double]$coordinates[1] - 4), 8, 8)
    $dot.Dispose()
}
$graphics.ResetTransform()
foreach ($file in @('splash-2732x2732-2.png', 'splash-2732x2732-1.png', 'splash-2732x2732.png')) {
    $splash.Save((Join-Path $splashFolder $file), [System.Drawing.Imaging.ImageFormat]::Png)
}
$middle.Dispose()
$accent.Dispose()
$logo.Dispose()
$graphics.Dispose()
$splash.Dispose()
